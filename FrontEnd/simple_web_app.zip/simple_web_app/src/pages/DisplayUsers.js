import axios from "axios";
import MainBox from "../components/layout/MainBox.js";
import UserList from "../components/user/UserList";
import { useState, useEffect } from "react";

function DisplayUsers() {
  const [users, setUsers] = useState([]);

  useEffect(() => {
    const fetch_data = async () => {
      await axios.get("http://localhost:8080/api/users").then(
        (response) => {
          console.log(response.status);
          setUsers(response.data);
          console.log(response.data);
        },
        (error) => {
          console.log(error);
        }
      );
    };

    fetch_data();
  }, []);

  return <MainBox title="All Users" content={<UserList users={users} />} />;
}

export default DisplayUsers;
