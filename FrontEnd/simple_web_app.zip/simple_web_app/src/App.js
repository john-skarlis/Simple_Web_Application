import { Route } from "react-router-dom";
import HomePage from "./pages/HomePage";
import DisplayUsers from "./pages/DisplayUsers";
import RegisterNewUser from "./pages/RegisterNewUser";
import MainNavigation from "./components/layout/MainNavigation";
import { Switch } from "react-router-dom";
import UserInfo from "./components/user/UserInfo";

function App() {
  return (
    <div>
      <MainNavigation />
      <Switch>
        <Route path="/" exact={true} component={HomePage} />
        <Route path="/users" component={DisplayUsers} exact={true} />
        <Route path="/register" component={RegisterNewUser} />
        <Route path="/users/:id" component={UserInfo} />
      </Switch>
    </div>
  );
}

export default App;
