import axios from "axios";
import moment from "moment";
import { useRef, useState } from "react";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import { Link, useHistory } from "react-router-dom";

function RegisterUserForm() {
  const history = useHistory();
  var registerString = "";
  const name = useRef();
  const surname = useRef();
  const gender = useRef();
  const workAddress = useRef();
  const homeAddress = useRef();

  const options = [
    { value: "Male", label: "Male" },
    { value: "Female", label: "Female" },
  ];

  const [startDate, setStartDate] = useState(new Date());
  function SubmitAction(event) {
    event.preventDefault();

    const user = {
      name: name.current.value,
      surname: surname.current.value,
      gender: gender.current.value,
      date: moment(startDate).format("YYYY-MM-DD"),
      home_address: homeAddress.current.value,
      work_address: workAddress.current.value,
    };

    console.log(user);

    axios.post("http://localhost:8080/api/users", user).then(
      (response) => {
        console.log(response);
        if (response.data === "This user already exists") {
          registerString = "This user already exists";
          alert(registerString);
        } else {
          registerString = "User saved successfully";
          history.replace("/");
        }
      },
      (error) => {
        console.log(error);
      }
    );
  }

  return (
    <form className="w-full max-w-sm" onSubmit={SubmitAction}>
      <div className="block sm:block items-center py-2 mt-5">
        <input
          key="name"
          className="flex items-center border-b border-green-400 appearance-none bg-transparent w-full text-gray-700 mr-3 py-1 px-2 mb-10 leading-tight focus:outline-none"
          type="text"
          placeholder="Name"
          required
          ref={name}
        />
        <input
          key="surname"
          className="flex items-center border-b border-green-400 appearance-none bg-transparent w-full text-gray-700 mr-3 py-1 px-2 mb-10 leading-tight focus:outline-none"
          type="text"
          placeholder="Surname"
          required
          ref={surname}
        />
        <select
          key="gender"
          className="form-select border-b border-green-400 p-1 block w-full mb-10"
          required
          ref={gender}
        >
          {options.map((option) => (
            <option key={option.label} value={option.value}>
              {option.label}
            </option>
          ))}
        </select>
        <div>
          <p className=" text-gray-400 inline-block border-b p-1 border-green-400 mr-3">
            Enter your birth date:
          </p>
          <DatePicker
            key="birth_date"
            required
            className="inline-block border-b mb-10 border-green-400 p-1"
            selected={startDate}
            onChange={(date) => setStartDate(date)}
            maxDate={new Date()}
            dateFormat="dd/MM/yyyy"
            showYearDropdown
            scrollableMonthYearDropdown
          />
        </div>
        <input
          key="work_address"
          className="flex items-center border-b border-green-400 appearance-none bg-transparent w-full text-gray-700 mr-3 py-1 px-2 mb-10 leading-tight focus:outline-none"
          type="text"
          placeholder="Work address"
          ref={workAddress}
        />
        <input
          key="home_address"
          className="flex items-center border-b border-green-400 appearance-none bg-transparent w-full text-gray-700 mr-3 py-1 px-2 mb-10 leading-tight focus:outline-none"
          type="text"
          placeholder="Home address"
          ref={homeAddress}
        />
        <button
          className="flex-shrink-0  border-b border-t border-r border-l rounded text-green-400 hover:text-green-700 border-green-400 hover:border-green-700 text-sm  text-white py-1 px-2 "
          type="submit"
        >
          Sign Up
        </button>
        <button
          className="flex-shrink-0 border-b text-green-400 border-green-400 hover:border-green-700 hover:text-green-700 text-sm py-1 px-2 ml-4"
          type="button"
        >
          <Link to="/"> Cancel</Link>
        </button>
      </div>
    </form>
  );
}

export default RegisterUserForm;
