import { useParams } from "react-router-dom";
import MainBox from "../layout/MainBox";
import ShowUser from "./ShowUser";
import { useState, useEffect } from "react";
import axios from "axios";

function UserInfo() {
  const { id } = useParams();
  const [user, setUser] = useState([]);

  useEffect(() => {
    const fetch_data = () => {
      axios.get(`http://localhost:8080/api/users/${id}`).then(
        (response) => {
          console.log(response.status);
          setUser(response.data);
          console.log(response.data);
        },
        (error) => {
          console.log(error);
        }
      );
    };
    fetch_data();
  }, []);

  return <MainBox title="Show user" content={<ShowUser user={user} />} />;
}

export default UserInfo;
