import axios from "axios";
import { Link, useHistory } from "react-router-dom";

function ShowUser({ user }) {
  const history = useHistory();
  function deleteHandler() {
    axios.delete(`http://localhost:8080/api/users/${user.user_id}`).then(
      (response) => {
        console.log(response.status);
        if (response.status === 200) {
          alert("User deleted");
          history.replace("/users");
        } else {
          alert("Something went wrong");
        }
      },
      (error) => {
        console.log(error);
      }
    );
  }
  return (
    <div className="max-w-sm mt-5">
      <div className="border-r border-b border-l border-green-400 lg:border-l lg:border-t lg:border-green-400 bg-white rounded-b lg:rounded-b-none  lg:rounded-l lg:rounded-r p-4 flex flex-col justify-between leading-normal">
        <div className="mb-8">
          <div className="text-gray-900 font-bold text-xl mb-2">
            {user.name + " " + user.surname}
          </div>
          <p className="text-gray-700 text-base">{"Gender: " + user.gender}</p>
          <p className="text-gray-700 text-base">
            {"Birth date: " + user.date}
          </p>
          <p className="text-gray-700 text-base">
            {"Work address: " + user.work_address}
          </p>
          <p className="text-gray-700 text-base">
            {"Home address: " + user.home_address}
          </p>
        </div>
        <div className="flex items-center">
          <button
            className="flex-shrink-0  border-b border-t border-r border-l rounded text-green-400 hover:text-green-700 border-green-400 hover:border-green-700 text-sm  text-white py-1 px-2 "
            type="submit"
          >
            <Link to="/users"> Back</Link>
          </button>
          <button
            className="flex-shrink-0 border-b text-green-400 border-green-400 hover:border-green-700 hover:text-green-700 text-sm py-1 px-2 ml-4"
            type="button"
            onClick={deleteHandler}
          >
            Delete
          </button>
        </div>
      </div>
    </div>
  );
}

export default ShowUser;
